module.exports = {
  content: [],
  theme: {
    extend: {},
  },
  plugins: [],
}
