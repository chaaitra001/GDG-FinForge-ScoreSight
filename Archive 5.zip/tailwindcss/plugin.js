let createPlugin = require('./lib/public/create-plugin')
module.exports = (createPlugin.__esModule ? createPlugin : { default: createPlugin }).default
