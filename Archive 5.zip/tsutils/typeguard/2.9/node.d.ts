export * from '../2.8/node';
import * as ts from 'typescript';
export declare function isImportTypeNode(node: ts.Node): node is ts.ImportTypeNode;
