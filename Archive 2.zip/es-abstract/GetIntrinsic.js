'use strict';

// TODO: remove, semver-major

module.exports = require('get-intrinsic');
