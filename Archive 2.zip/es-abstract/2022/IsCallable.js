'use strict';

// http://262.ecma-international.org/5.1/#sec-9.11

module.exports = require('is-callable');
