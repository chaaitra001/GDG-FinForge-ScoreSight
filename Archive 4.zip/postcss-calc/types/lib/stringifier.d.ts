declare function _exports(calc: string, node: import('../parser').CalcNode, originalValue: string, options: {
    precision: number | false;
    warnWhenCannotResolve: boolean;
}, result: import("postcss").Result, item: import("postcss").ChildNode): string;
export = _exports;
