# Changes to PostCSS Attribute Case Insensitive

### 5.0.2 (June 8, 2022)

- Fix incorrect selector AST updates

### 5.0.1 (3 June, 2022)

- Prevent exponential backtracking when checking for selectors with case insensitive value matching.

### 5.0.0 (15 September, 2020)

- Postcss 8.x support

### 4.0.1 (10 January, 2019)

### 2.0.0 (06 May, 2017)

### 1.0.1 (19 August, 2016)

### 1.0.0 (10 August, 2016)
