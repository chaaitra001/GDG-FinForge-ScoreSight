/**
 * @param {string} value
 * @return {boolean}
 */
export function isStyle(value: string): boolean;
/**
 * @param {string} value
 * @return {boolean}
 */
export function isWidth(value: string): boolean;
/**
 * @param {string} value
 * @return {boolean}
 */
export function isColor(value: string): boolean;
/**
 * @param {[string, string, string]} wscs
 * @return {boolean}
 */
export function isValidWsc(wscs: [string, string, string]): boolean;
