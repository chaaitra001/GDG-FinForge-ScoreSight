declare function isString(value: unknown): value is string | String;

export = isString;