let { task, namespace } = require(`${process.env.PROJECT_DIR}/lib/jake`);

namespace('usingRequire', function () {
  task('test', () => {
    console.log('howdy test');
  });
});



