declare function isRegex(value: unknown): value is RegExp;

export = isRegex;
