declare function isBooleanObject(value: unknown): value is boolean | Boolean;

export = isBooleanObject;
