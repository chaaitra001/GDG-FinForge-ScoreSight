import idObj from '..';

export default idObj;
