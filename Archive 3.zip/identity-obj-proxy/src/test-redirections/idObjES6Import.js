import idObj from '..';

module.exports = idObj;
